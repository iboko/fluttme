import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/providers/transactions_provider.dart';
import 'package:xianyu_finance/widgets/transaction_list_tile.dart';
import 'package:xianyu_finance/widgets/error_view.dart';
import 'package:xianyu_finance/widgets/loading_view.dart';
import 'package:xianyu_finance/services/api_service.dart';
import 'package:xianyu_finance/utils/logger.dart';

/// Screen that displays details of a specific account and its transactions.
class AccountDetailScreen extends StatelessWidget {
  final Account account;

  const AccountDetailScreen({Key? key, required this.account}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => TransactionsProvider(
        context.read<ApiService>(),
        account.id,
      ),
      child: Scaffold(
        appBar: AppBar(
          title: Text(account.name),
          actions: [
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => _editAccount(context),
            ),
          ],
        ),
        body: _buildBody(),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _addNewTransaction(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  Widget _buildBody() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildAccountSummary(),
        const Divider(),
        Expanded(
          child: _buildTransactionsList(),
        ),
      ],
    );
  }

  Widget _buildAccountSummary() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Balance: \$${account.balance.toStringAsFixed(2)}',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Account ID: ${account.id}'),
        ],
      ),
    );
  }

  Widget _buildTransactionsList() {
    return Consumer<TransactionsProvider>(
      builder: (context, transactionsProvider, child) {
        if (transactionsProvider.isLoading) {
          return const LoadingView();
        } else if (transactionsProvider.errorMessage != null) {
          return ErrorView(
            message: transactionsProvider.errorMessage!,
            onRetry: () => transactionsProvider.fetchTransactions(),
          );
        } else if (transactionsProvider.transactions.isEmpty) {
          return const Center(child: Text('No transactions found.'));
        } else {
          return ListView.builder(
            itemCount: transactionsProvider.transactions.length,
            itemBuilder: (context, index) {
              final transaction = transactionsProvider.transactions[index];
              return TransactionListTile(
                transaction: transaction,
                onTap: () => _viewTransactionDetails(context, transaction),
              );
            },
          );
        }
      },
    );
  }

  void _editAccount(BuildContext context) {
    // TODO: Implement edit account functionality
    Logger.info('Edit account tapped for account ID: ${account.id}');
  }

  void _addNewTransaction(BuildContext context) {
    // TODO: Implement add new transaction functionality
    Logger.info('Add new transaction tapped for account ID: ${account.id}');
  }

  void _viewTransactionDetails(BuildContext context, Transaction transaction) {
    // TODO: Implement view transaction details functionality
    Logger.info('View transaction details tapped for transaction ID: ${transaction.id}');
  }
}