import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:xianyu_finance/providers/accounts_provider.dart';
import 'package:xianyu_finance/screens/account_detail_screen.dart';
import 'package:xianyu_finance/widgets/account_list_tile.dart';
import 'package:xianyu_finance/widgets/error_view.dart';
import 'package:xianyu_finance/widgets/loading_view.dart';
import 'package:xianyu_finance/utils/logger.dart';

/// Screen that displays a list of all accounts.
class AccountsScreen extends StatelessWidget {
  const AccountsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Using Consumer for fine-grained rebuilds
    return Consumer<AccountsProvider>(
      builder: (context, accountsProvider, child) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Accounts'),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: () => _refreshAccounts(context),
              ),
            ],
          ),
          body: _buildBody(accountsProvider),
          floatingActionButton: FloatingActionButton(
            onPressed: () => _addNewAccount(context),
            child: const Icon(Icons.add),
          ),
        );
      },
    );
  }

  Widget _buildBody(AccountsProvider accountsProvider) {
    if (accountsProvider.isLoading) {
      return const LoadingView();
    } else if (accountsProvider.errorMessage != null) {
      return ErrorView(
        message: accountsProvider.errorMessage!,
        onRetry: () => accountsProvider.fetchAccounts(),
      );
    } else if (accountsProvider.accounts.isEmpty) {
      return const Center(child: Text('No accounts found. Add one to get started!'));
    } else {
      return ListView.builder(
        itemCount: accountsProvider.accounts.length,
        itemBuilder: (context, index) {
          final account = accountsProvider.accounts[index];
          return AccountListTile(
            account: account,
            onTap: () => _navigateToAccountDetail(context, account),
          );
        },
      );
    }
  }

  void _refreshAccounts(BuildContext context) {
    context.read<AccountsProvider>().fetchAccounts();
  }

  void _addNewAccount(BuildContext context) {
    // TODO: Implement add new account functionality
    Logger.info('Add new account tapped');
  }

  void _navigateToAccountDetail(BuildContext context, Account account) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AccountDetailScreen(account: account),
      ),
    );
  }
}