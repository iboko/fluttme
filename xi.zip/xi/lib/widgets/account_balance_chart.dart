import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/utils/color_utils.dart';

/// A widget that displays a pie chart of account balances.
class AccountBalanceChart extends StatelessWidget {
  final List<Account> accounts;

  /// Creates an [AccountBalanceChart].
  ///
  /// The [accounts] parameter is required and must not be empty.
  const AccountBalanceChart({Key? key, required this.accounts}) : assert(accounts.isNotEmpty), super(key: key);

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.3,
      child: PieChart(
        PieChartData(
          sections: _generatePieChartSections(),
          sectionsSpace: 0,
          centerSpaceRadius: 40,
          startDegreeOffset: -90,
        ),
      ),
    );
  }

  List<PieChartSectionData> _generatePieChartSections() {
    final totalBalance = accounts.fold<double>(0, (sum, account) => sum + account.balance.abs());
    
    return accounts.asMap().entries.map((entry) {
      final index = entry.key;
      final account = entry.value;
      final percentage = account.balance.abs() / totalBalance;
      
      return PieChartSectionData(
        color: ColorUtils.getColorFromIndex(index),
        value: percentage * 100,
        title: '${(percentage * 100).toStringAsFixed(1)}%',
        radius: 50,
        titleStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
      );
    }).toList();
  }
}