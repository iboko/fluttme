import 'package:flutter/material.dart';
import 'package:xianyu_finance/models/transaction.dart';
import 'package:xianyu_finance/utils/validators.dart';
import 'package:xianyu_finance/localization/app_localizations.dart';

/// A form widget for adding a new transaction.
class AddTransactionForm extends StatefulWidget {
  final Function(Transaction) onSubmit;

  const AddTransactionForm({Key? key, required this.onSubmit}) : super(key: key);

  @override
  _AddTransactionFormState createState() => _AddTransactionFormState();
}

class _AddTransactionFormState extends State<AddTransactionForm> {
  final _formKey = GlobalKey<FormState>();
  final _descriptionController = TextEditingController();
  final _amountController = TextEditingController();
  DateTime _selectedDate = DateTime.now();

  @override
  void dispose() {
    _descriptionController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final transaction = Transaction(
        id: DateTime.now().toString(), // временный ID
        description: _descriptionController.text,
        amount: double.parse(_amountController.text),
        date: _selectedDate,
      );
      widget.onSubmit(transaction);
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextFormField(
            controller: _descriptionController,
            decoration: InputDecoration(labelText: localizations.transactionDescription),
            validator: Validators.required(localizations.descriptionRequired),
          ),
          TextFormField(
            controller: _amountController,
            decoration: InputDecoration(labelText: localizations.amount),
            keyboardType: TextInputType.number,
            validator: Validators.compose([
              Validators.required(localizations.amountRequired),
              Validators.numeric(localizations.amountMustBeNumber),
            ]),
          ),
          ListTile(
            title: Text(localizations.date),
            subtitle: Text('${_selectedDate.toLocal()}'.split(' ')[0]),
            trailing: Icon(Icons.calendar_today),
            onTap: () => _selectDate(context),
          ),
          Center(
            child: ElevatedButton(
              onPressed: _submitForm,
              child: Text(localizations.addTransaction),
            ),
          ),
        ],
      ),
    );
  }
}