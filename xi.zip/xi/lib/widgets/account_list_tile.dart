import 'package:flutter/material.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:intl/intl.dart';

/// A custom ListTile for displaying account information.
class AccountListTile extends StatelessWidget {
  final Account account;
  final VoidCallback? onTap;

  /// Creates an [AccountListTile].
  ///
  /// The [account] parameter is required and must not be null.
  const AccountListTile({
    Key? key,
    required this.account,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Using NumberFormat for proper currency formatting
    final currencyFormat = NumberFormat.currency(symbol: '\$');

    return ListTile(
      title: Text(account.name),
      subtitle: Text('ID: ${account.id}'),
      trailing: Text(
        currencyFormat.format(account.balance),
        style: TextStyle(
          color: account.balance >= 0 ? Colors.green : Colors.red,
          fontWeight: FontWeight.bold,
        ),
      ),
      onTap: onTap,
    );
  }
}