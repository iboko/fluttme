import 'package:flutter/material.dart';
import 'package:xianyu_finance/models/transaction.dart';
import 'package:intl/intl.dart';

/// A custom ListTile for displaying transaction information.
class TransactionListTile extends StatelessWidget {
  final Transaction transaction;
  final VoidCallback? onTap;

  /// Creates a [TransactionListTile].
  ///
  /// The [transaction] parameter is required and must not be null.
  const TransactionListTile({
    Key? key,
    required this.transaction,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Using NumberFormat for proper currency formatting
    final currencyFormat = NumberFormat.currency(symbol: '\$');
    // Using DateFormat for formatting the transaction date
    final dateFormat = DateFormat('MMM d, yyyy');

    return ListTile(
      title: Text(transaction.description),
      subtitle: Text(dateFormat.format(transaction.date)),
      trailing: Text(
        currencyFormat.format(transaction.amount),
        style: TextStyle(
          color: transaction.amount >= 0 ? Colors.green : Colors.red,
          fontWeight: FontWeight.bold,
        ),
      ),
      onTap: onTap,
    );
  }
}