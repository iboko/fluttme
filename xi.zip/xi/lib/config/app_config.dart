/// Configuration class for the application.
/// Centralizing configuration values for easy management and updates.
class AppConfig {
  /// Base URL for the API. Using a const for compile-time optimization.
  static const String apiBaseUrl = 'https://api.xianyu.com';

  /// Timeout duration for API requests in milliseconds.
  /// Adjusting this value allows fine-tuning of network request behavior.
  static const int apiTimeoutMs = 10000;

  /// Maximum number of retry attempts for failed API requests.
  /// Balancing between user experience and server load.
  static const int maxApiRetries = 3;

  /// Feature flag for enabling dark mode.
  /// Useful for A/B testing or phased rollout of dark mode feature.
  static const bool enableDarkMode = false;

  /// Minimum supported app version. 
  /// Used for forcing app updates when necessary.
  static const String minSupportedVersion = '1.0.0';

  // Private constructor to prevent instantiation
  AppConfig._();
}