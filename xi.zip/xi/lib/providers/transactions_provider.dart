import 'package:flutter/foundation.dart';
import 'package:xianyu_finance/services/api_service.dart';
import 'package:xianyu_finance/models/transaction.dart';
import 'package:xianyu_finance/utils/logger.dart';

/// Manages the state of transactions for a specific account.
/// Uses ChangeNotifier for efficient UI updates.
class TransactionsProvider with ChangeNotifier {
  final ApiService _apiService;
  final int _accountId;
  List<Transaction> _transactions = [];
  bool _isLoading = false;
  String? _errorMessage;

  TransactionsProvider(this._apiService, this._accountId) {
    fetchTransactions();
  }

  List<Transaction> get transactions => List.unmodifiable(_transactions);
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> fetchTransactions() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _transactions = await _apiService.getTransactions(_accountId);
      Logger.info('Fetched ${_transactions.length} transactions for account $_accountId');
    } catch (e) {
      _errorMessage = 'Failed to fetch transactions: ${e.toString()}';
      Logger.error(_errorMessage!);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addTransaction(Transaction transaction) async {
    try {
      final newTransaction = await _apiService.createTransaction(_accountId, transaction);
      _transactions.add(newTransaction);
      notifyListeners();
      Logger.info('Added new transaction: ${newTransaction.description}');
    } catch (e) {
      _errorMessage = 'Failed to add transaction: ${e.toString()}';
      Logger.error(_errorMessage!);
      notifyListeners();
    }
  }

  Future<void> updateTransaction(Transaction updatedTransaction) async {
    try {
      final result = await _apiService.updateTransaction(_accountId, updatedTransaction);
      final index = _transactions.indexWhere((t) => t.id == result.id);
      if (index != -1) {
        _transactions[index] = result;
        notifyListeners();
        Logger.info('Updated transaction: ${result.description}');
      } else {
        throw Exception('Transaction not found');
      }
    } catch (e) {
      _errorMessage = 'Failed to update transaction: ${e.toString()}';
      Logger.error(_errorMessage!);
      notifyListeners();
    }
  }

  Future<void> deleteTransaction(String transactionId) async {
    try {
      await _apiService.deleteTransaction(_accountId, transactionId);
      _transactions.removeWhere((transaction) => transaction.id == transactionId);
      notifyListeners();
      Logger.info('Deleted transaction with ID: $transactionId');
    } catch (e) {
      _errorMessage = 'Failed to delete transaction: ${e.toString()}';
      Logger.error(_errorMessage!);
      notifyListeners();
    }
  }
}