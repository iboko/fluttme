import 'package:flutter/foundation.dart';
import 'package:xianyu_finance/services/api_service.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/utils/logger.dart';

/// Manages the state of accounts in the application.
/// Uses ChangeNotifier for efficient UI updates.
class AccountsProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Account> _accounts = [];
  bool _isLoading = false;
  String? _errorMessage;

  AccountsProvider(this._apiService) {
    fetchAccounts();
  }

  List<Account> get accounts => List.unmodifiable(_accounts);
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> fetchAccounts() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _accounts = await _apiService.getAccounts();
      Logger.info('Successfully fetched ${_accounts.length} accounts');
    } catch (e) {
      _errorMessage = 'Failed to fetch accounts: ${e.toString()}';
      Logger.error(_errorMessage!);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addAccount(Account account) async {
    try {
      final newAccount = await _apiService.createAccount(account);
      _accounts.add(newAccount);
      notifyListeners();
      Logger.info('Added new account: ${newAccount.name}');
    } catch (e) {
      _errorMessage = 'Failed to add account: ${e.toString()}';
      Logger.error(_errorMessage!);
      notifyListeners();
    }
  }

  Future<void> updateAccount(Account updatedAccount) async {
    try {
      final result = await _apiService.updateAccount(updatedAccount);
      final index = _accounts.indexWhere((a) => a.id == result.id);
      if (index != -1) {
        _accounts[index] = result;
        notifyListeners();
        Logger.info('Updated account: ${result.name}');
      } else {
        throw Exception('Account not found');
      }
    } catch (e) {
      _errorMessage = 'Failed to update account: ${e.toString()}';
      Logger.error(_errorMessage!);
      notifyListeners();
    }
  }

  Future<void> deleteAccount(int accountId) async {
    try {
      await _apiService.deleteAccount(accountId);
      _accounts.removeWhere((account) => account.id == accountId);
      notifyListeners();
      Logger.info('Deleted account with ID: $accountId');
    } catch (e) {
      _errorMessage = 'Failed to delete account: ${e.toString()}';
      Logger.error(_errorMessage!);
      notifyListeners();
    }
  }
}