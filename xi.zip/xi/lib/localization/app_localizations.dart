import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

/// A class that provides localized strings for the application.
class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = [
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];

  static const List<Locale> supportedLocales = [
    Locale('en', ''), // English
    Locale('zh', ''), // Chinese
  ];

  String get appTitle => Intl.message('Xianyu Finance', name: 'appTitle');
  String get accountsTitle => Intl.message('Accounts', name: 'accountsTitle');
  String get transactionsTitle => Intl.message('Transactions', name: 'transactionsTitle');
  String get balance => Intl.message('Balance', name: 'balance');
  String get noAccountsFound => Intl.message('No accounts found. Add one to get started!', name: 'noAccountsFound');
  String get noTransactionsFound => Intl.message('No transactions found.', name: 'noTransactionsFound');
  String get addAccount => Intl.message('Add Account', name: 'addAccount');
  String get editAccount => Intl.message('Edit Account', name: 'editAccount');
  String get addTransaction => Intl.message('Add Transaction', name: 'addTransaction');
  String get editTransaction => Intl.message('Edit Transaction', name: 'editTransaction');
  String get loading => Intl.message('Loading...', name: 'loading');
  String get retry => Intl.message('Retry', name: 'retry');
  String get error => Intl.message('An error occurred', name: 'error');

  String accountBalance(double balance) => Intl.message(
    'Balance: \$$balance',
    name: 'accountBalance',
    args: [balance],
  );
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return ['en', 'zh'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    final localizations = AppLocalizations(locale);
    await Intl.defaultLocale = locale.toString();
    return localizations;
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}