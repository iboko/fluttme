import 'package:equatable/equatable.dart';

/// Represents a financial account in the application.
/// Extending Equatable for easy equality comparisons.
class Account extends Equatable {
  /// Unique identifier for the account.
  final int id;

  /// Name of the account.
  final String name;

  /// Current balance of the account.
  final double balance;

  /// Creates an [Account] instance.
  /// Using const constructor for performance optimization.
  const Account({
    required this.id,
    required this.name,
    required this.balance,
  });

  /// Creates an [Account] instance from a JSON map.
  /// Factory constructor for easy deserialization from API responses.
  factory Account.fromJson(Map<String, dynamic> json) {
    return Account(
      id: json['id'] as int,
      name: json['name'] as String,
      balance: (json['balance'] as num).toDouble(),
    );
  }

  /// Converts the [Account] instance to a JSON map.
  /// Useful for sending account data to the API or storing locally.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'balance': balance,
    };
  }

  /// Implementing props for Equatable.
  /// This defines which properties are used for equality comparisons.
  @override
  List<Object?> get props => [id, name, balance];

  /// Creating a copy of this Account with optional new values.
  /// Useful for immutable state updates in the app.
  Account copyWith({
    int? id,
    String? name,
    double? balance,
  }) {
    return Account(
      id: id ?? this.id,
      name: name ?? this.name,
      balance: balance ?? this.balance,
    );
  }
}