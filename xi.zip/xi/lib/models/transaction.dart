import 'package:equatable/equatable.dart';

/// Represents a financial transaction in the application.
/// Extending Equatable for easy equality comparisons.
class Transaction extends Equatable {
  /// Unique identifier for the transaction.
  final String id;

  /// Description of the transaction.
  final String description;

  /// Amount of the transaction.
  final double amount;

  /// Date and time when the transaction occurred.
  final DateTime date;

  /// Creates a [Transaction] instance.
  /// Using const constructor for performance optimization.
  const Transaction({
    required this.id,
    required this.description,
    required this.amount,
    required this.date,
  });

  /// Creates a [Transaction] instance from a JSON map.
  /// Factory constructor for easy deserialization from API responses.
  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      id: json['id'] as String,
      description: json['description'] as String,
      amount: (json['amount'] as num).toDouble(),
      date: DateTime.parse(json['date'] as String),
    );
  }

  /// Converts the [Transaction] instance to a JSON map.
  /// Useful for sending transaction data to the API or storing locally.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'description': description,
      'amount': amount,
      'date': date.toIso8601String(),
    };
  }

  /// Implementing props for Equatable.
  /// This defines which properties are used for equality comparisons.
  @override
  List<Object?> get props => [id, description, amount, date];

  /// Creating a copy of this Transaction with optional new values.
  /// Useful for immutable state updates in the app.
  Transaction copyWith({
    String? id,
    String? description,
    double? amount,
    DateTime? date,
  }) {
    return Transaction(
      id: id ?? this.id,
      description: description ?? this.description,
      amount: amount ?? this.amount,
      date: date ?? this.date,
    );
  }
}