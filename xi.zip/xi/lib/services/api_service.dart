import 'package:dio/dio.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/models/transaction.dart';
import 'package:xianyu_finance/config/app_config.dart';
import 'package:xianyu_finance/utils/logger.dart';

/// Service for making API calls to the backend.
/// Utilizes Dio for efficient HTTP requests and interceptors.
class ApiService {
  late final Dio _dio;

  ApiService() {
    _dio = Dio(
      BaseOptions(
        baseUrl: AppConfig.apiBaseUrl,
        connectTimeout: AppConfig.apiTimeoutMs,
        receiveTimeout: AppConfig.apiTimeoutMs,
      ),
    );
    _setupInterceptors();
  }

  /// Sets up interceptors for logging and error handling.
  /// This is a best practice for centralized request/response processing.
  void _setupInterceptors() {
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) {
        Logger.info('Request: ${options.method} ${options.path}');
        return handler.next(options);
      },
      onResponse: (response, handler) {
        Logger.info('Response: ${response.statusCode}');
        return handler.next(response);
      },
      onError: (DioError e, handler) {
        Logger.error('API Error: ${e.message}');
        return handler.next(e);
      },
    ));
  }

  /// Fetches the list of accounts from the API.
  Future<List<Account>> getAccounts() async {
    try {
      final response = await _dio.get('/accounts');
      return (response.data as List).map((json) => Account.fromJson(json)).toList();
    } catch (e) {
      Logger.error('Failed to fetch accounts: $e');
      rethrow; // Rethrow to allow providers to handle the error
    }
  }

  /// Creates a new account via the API.
  Future<Account> createAccount(Account account) async {
    try {
      final response = await _dio.post('/accounts', data: account.toJson());
      return Account.fromJson(response.data);
    } catch (e) {
      Logger.error('Failed to create account: $e');
      rethrow;
    }
  }

  /// Updates an existing account via the API.
  Future<Account> updateAccount(Account account) async {
    try {
      final response = await _dio.put('/accounts/${account.id}', data: account.toJson());
      return Account.fromJson(response.data);
    } catch (e) {
      Logger.error('Failed to update account: $e');
      rethrow;
    }
  }

  /// Deletes an account via the API.
  Future<void> deleteAccount(int accountId) async {
    try {
      await _dio.delete('/accounts/$accountId');
    } catch (e) {
      Logger.error('Failed to delete account: $e');
      rethrow;
    }
  }

  /// Fetches transactions for a specific account from the API.
  Future<List<Transaction>> getTransactions(int accountId) async {
    try {
      final response = await _dio.get('/accounts/$accountId/transactions');
      return (response.data as List).map((json) => Transaction.fromJson(json)).toList();
    } catch (e) {
      Logger.error('Failed to fetch transactions: $e');
      rethrow;
    }
  }

  /// Creates a new transaction for a specific account via the API.
  Future<Transaction> createTransaction(int accountId, Transaction transaction) async {
    try {
      final response = await _dio.post('/accounts/$accountId/transactions', data: transaction.toJson());
      return Transaction.fromJson(response.data);
    } catch (e) {
      Logger.error('Failed to create transaction: $e');
      rethrow;
    }
  }

  /// Updates an existing transaction for a specific account via the API.
  Future<Transaction> updateTransaction(int accountId, Transaction transaction) async {
    try {
      final response = await _dio.put('/accounts/$accountId/transactions/${transaction.id}', data: transaction.toJson());
      return Transaction.fromJson(response.data);
    } catch (e) {
      Logger.error('Failed to update transaction: $e');
      rethrow;
    }
  }

  /// Deletes a transaction for a specific account via the API.
  Future<void> deleteTransaction(int accountId, String transactionId) async {
    try {
      await _dio.delete('/accounts/$accountId/transactions/$transactionId');
    } catch (e) {
      Logger.error('Failed to delete transaction: $e');
      rethrow;
    }
  }
}