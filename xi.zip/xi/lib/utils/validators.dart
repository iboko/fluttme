/// A utility class that provides form field validators.
class Validators {
  /// Returns a validator that requires the field to be non-empty.
  static FormFieldValidator<String> required(String errorMessage) {
    return (value) {
      if (value == null || value.isEmpty) {
        return errorMessage;
      }
      return null;
    };
  }

  /// Returns a validator that ensures the input is a valid number.
  static FormFieldValidator<String> numeric(String errorMessage) {
    return (value) {
      if (value == null || double.tryParse(value) == null) {
        return errorMessage;
      }
      return null;
    };
  }

  /// Combines multiple validators into a single validator.
  static FormFieldValidator<String> compose(List<FormFieldValidator<String>> validators) {
    return (value) {
      for (final validator in validators) {
        final result = validator(value);
        if (result != null) return result;
      }
      return null;
    };
  }

  /// Returns a validator that ensures the input is a valid email address.
  static FormFieldValidator<String> email(String errorMessage) {
    return (value) {
      if (value == null || !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
        return errorMessage;
      }
      return null;
    };
  }

  /// Returns a validator that ensures the input meets a minimum length requirement.
  static FormFieldValidator<String> minLength(int minLength, String errorMessage) {
    return (value) {
      if (value == null || value.length < minLength) {
        return errorMessage;
      }
      return null;
    };
  }
}