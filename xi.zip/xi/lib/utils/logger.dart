import 'package:logger/logger.dart' as log_package;
import 'package:xianyu_finance/config/app_config.dart';

/// A centralized logging utility for the application.
/// Wraps the logger package to provide consistent logging across the app.
class Logger {
  static final log_package.Logger _logger = log_package.Logger(
    printer: log_package.PrettyPrinter(
      methodCount: 2, // Number of method calls to be displayed
      errorMethodCount: 8, // Number of method calls if stacktrace is provided
      lineLength: 120, // Width of the output
      colors: true, // Colorful log messages
      printEmojis: true, // Print an emoji for each log message
      printTime: true // Should each log print contain a timestamp
    ),
  );

  /// Logs an info message.
  static void info(String message) {
    _logger.i(message);
  }

  /// Logs a debug message.
  static void debug(String message) {
    if (AppConfig.enableDebugLogging) {
      _logger.d(message);
    }
  }

  /// Logs a warning message.
  static void warning(String message) {
    _logger.w(message);
  }

  /// Logs an error message and optionally an exception.
  static void error(String message, [dynamic error, StackTrace? stackTrace]) {
    _logger.e(message, error: error, stackTrace: stackTrace);
  }

  /// Logs a verbose message.
  static void verbose(String message) {
    if (AppConfig.enableVerboseLogging) {
      _logger.v(message);
    }
  }
}