import 'package:flutter/material.dart';

/// A utility class for managing colors in the application.
class ColorUtils {
  /// A list of predefined colors for use in charts and other visualizations.
  static const List<Color> chartColors = [
    Color(0xFF4285F4), // Google Blue
    Color(0xFFDB4437), // Google Red
    Color(0xFFF4B400), // Google Yellow
    Color(0xFF0F9D58), // Google Green
    Color(0xFF7B1FA2), // Purple
    Color(0xFF0097A7), // Cyan
    Color(0xFFFF5722), // Deep Orange
    Color(0xFF795548), // Brown
  ];

  /// Returns a color from the [chartColors] list based on the given index.
  ///
  /// If the index is out of range, it wraps around to the beginning of the list.
  static Color getColorFromIndex(int index) {
    return chartColors[index % chartColors.length];
  }

  /// Determines if a color is light or dark.
  ///
  /// This is useful for determining text color to ensure readability.
  static bool isLightColor(Color color) {
    return color.computeLuminance() > 0.5;
  }

  /// Returns either black or white, whichever contrasts more with the given color.
  static Color contrastingTextColor(Color backgroundColor) {
    return isLightColor(backgroundColor) ? Colors.black : Colors.white;
  }
}