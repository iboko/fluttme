import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:xianyu_finance/config/app_config.dart';
import 'package:xianyu_finance/screens/accounts_screen.dart';
import 'package:xianyu_finance/services/api_service.dart';
import 'package:xianyu_finance/providers/accounts_provider.dart';
import 'package:xianyu_finance/localization/app_localizations.dart';
import 'package:xianyu_finance/utils/logger.dart';

/// Entry point of the application.
void main() {
  // Ensuring widget binding is initialized to interact with the Flutter engine.
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initializing the logger for consistent logging throughout the app.
  Logger.init();
  
  // Launching the app with the root widget.
  runApp(const XianyuFinanceApp());
}

/// Root widget of the Xianyu Finance application.
/// Using StatelessWidget as the app's state is managed by providers.
class XianyuFinanceApp extends StatelessWidget {
  /// Constructor marked as const to optimize performance.
  const XianyuFinanceApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      // Setting up providers for dependency injection and state management.
      providers: [
        // Providing a single instance of ApiService throughout the app.
        Provider<ApiService>(
          create: (_) => ApiService(baseUrl: AppConfig.apiBaseUrl),
        ),
        // Using ChangeNotifierProxyProvider to rebuild AccountsProvider when ApiService changes.
        ChangeNotifierProxyProvider<ApiService, AccountsProvider>(
          create: (context) => AccountsProvider(
            context.read<ApiService>(),
          ),
          update: (context, apiService, previous) =>
              previous ?? AccountsProvider(apiService),
        ),
      ],
      child: MaterialApp(
        title: 'Xianyu Finance Tracker',
        theme: ThemeData(
          primarySwatch: Colors.green,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          // Applying a consistent text theme across the app.
          textTheme: Typography.material2018().black,
        ),
        // Setting up localization for multi-language support.
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
        // Using a builder to set up a global error boundary.
        builder: (context, child) {
          return ErrorBoundary(child: child!);
        },
        // Setting the home screen of the app.
        home: const AccountsScreen(),
      ),
    );
  }
}

/// Widget that catches and handles errors in its child widget tree.
/// This provides a last line of defense against unhandled exceptions.
class ErrorBoundary extends StatelessWidget {
  final Widget child;

  const ErrorBoundary({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Overriding the default error widget builder to provide a custom error screen.
    ErrorWidget.builder = (FlutterErrorDetails errorDetails) {
      // Logging the error for debugging purposes.
      Logger.error('Caught unhandled error: ${errorDetails.exception}');
      return Scaffold(
        body: Center(
          child: Text(
            'An unexpected error occurred.\nPlease restart the app.',
            style: Theme.of(context).textTheme.headline6,
            textAlign: TextAlign.center,
          ),
        ),
      );
    };
    return child;
  }
}