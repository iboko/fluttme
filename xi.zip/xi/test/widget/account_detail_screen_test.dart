import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:mockito/mockito.dart';
import 'package:xianyu_finance/screens/account_detail_screen.dart';
import 'package:xianyu_finance/providers/transactions_provider.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/models/transaction.dart';

class MockTransactionsProvider extends Mock implements TransactionsProvider {}

void main() {
  late MockTransactionsProvider mockTransactionsProvider;
  final testAccount = Account(id: 1, name: 'Test Account', balance: 1000.0);

  setUp(() {
    mockTransactionsProvider = MockTransactionsProvider();
  });

  Widget createAccountDetailScreen() {
    return MaterialApp(
      home: ChangeNotifierProvider<TransactionsProvider>.value(
        value: mockTransactionsProvider,
        child: AccountDetailScreen(account: testAccount),
      ),
    );
  }

  group('AccountDetailScreen', () {
    testWidgets('displays account information', (WidgetTester tester) async {
      when(mockTransactionsProvider.isLoading).thenReturn(false);
      when(mockTransactionsProvider.transactions).thenReturn([]);

      await tester.pumpWidget(createAccountDetailScreen());

      expect(find.text('Test Account'), findsOneWidget);
      expect(find.text('Balance: \$1000.00'), findsOneWidget);
    });

    testWidgets('displays loading indicator when loading transactions', (WidgetTester tester) async {
      when(mockTransactionsProvider.isLoading).thenReturn(true);
      when(mockTransactionsProvider.transactions).thenReturn([]);

      await tester.pumpWidget(createAccountDetailScreen());

      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('displays transactions when loaded', (WidgetTester tester) async {
      final transactions = [
        Transaction(id: '1', description: 'Groceries', amount: -50.0, date: DateTime.now()),
        Transaction(id: '2', description: 'Salary', amount: 1000.0, date: DateTime.now()),
      ];

      when(mockTransactionsProvider.isLoading).thenReturn(false);
      when(mockTransactionsProvider.transactions).thenReturn(transactions);

      await tester.pumpWidget(createAccountDetailScreen());

      expect(find.text('Groceries'), findsOneWidget);
      expect(find.text('Salary'), findsOneWidget);
    });

    testWidgets('displays error message when there is an error', (WidgetTester tester) async {
      when(mockTransactionsProvider.isLoading).thenReturn(false);
      when(mockTransactionsProvider.errorMessage).thenReturn('Error loading transactions');
      when(mockTransactionsProvider.transactions).thenReturn([]);

      await tester.pumpWidget(createAccountDetailScreen());

      expect(find.text('Error loading transactions'), findsOneWidget);
    });

    
  });
}