import 'package:flutter_test/flutter_test.dart';
import 'package:xianyu_finance/models/transaction.dart';

void main() {
  group('Transaction', () {
    test('should create Transaction instance from JSON', () {
      final json = {
        'id': '1',
        'description': 'Groceries',
        'amount': -50.0,
        'date': '2023-07-30T10:00:00Z'
      };
      final transaction = Transaction.fromJson(json);

      expect(transaction.id, '1');
      expect(transaction.description, 'Groceries');
      expect(transaction.amount, -50.0);
      expect(transaction.date, DateTime.parse('2023-07-30T10:00:00Z'));
    });

    test('should convert Transaction instance to JSON', () {
      final date = DateTime.parse('2023-07-30T10:00:00Z');
      final transaction = Transaction(
        id: '1',
        description: 'Groceries',
        amount: -50.0,
        date: date
      );
      final json = transaction.toJson();

      expect(json, {
        'id': '1',
        'description': 'Groceries',
        'amount': -50.0,
        'date': date.toIso8601String()
      });
    });

    test('copyWith should create a new instance with updated values', () {
      final original = Transaction(
        id: '1',
        description: 'Groceries',
        amount: -50.0,
        date: DateTime.parse('2023-07-30T10:00:00Z')
      );
      final updated = original.copyWith(amount: -75.0);

      expect(updated.id, original.id);
      expect(updated.description, original.description);
      expect(updated.amount, -75.0);
      expect(updated.date, original.date);
    });
  });
}