import 'package:flutter_test/flutter_test.dart';
import 'package:xianyu_finance/models/account.dart';

void main() {
  group('Account', () {
    test('should create Account instance from JSON', () {
      final json = {'id': 1, 'name': 'Savings', 'balance': 1000.0};
      final account = Account.fromJson(json);

      expect(account.id, 1);
      expect(account.name, 'Savings');
      expect(account.balance, 1000.0);
    });

    test('should convert Account instance to JSON', () {
      final account = Account(id: 1, name: 'Savings', balance: 1000.0);
      final json = account.toJson();

      expect(json, {'id': 1, 'name': 'Savings', 'balance': 1000.0});
    });

    test('copyWith should create a new instance with updated values', () {
      final original = Account(id: 1, name: 'Savings', balance: 1000.0);
      final updated = original.copyWith(balance: 1500.0);

      expect(updated.id, original.id);
      expect(updated.name, original.name);
      expect(updated.balance, 1500.0);
    });
  });
}