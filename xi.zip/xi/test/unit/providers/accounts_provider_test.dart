import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/providers/accounts_provider.dart';
import 'package:xianyu_finance/services/api_service.dart';

class MockApiService extends Mock implements ApiService {}

void main() {
  late AccountsProvider provider;
  late MockApiService mockApiService;

  setUp(() {
    mockApiService = MockApiService();
    provider = AccountsProvider(mockApiService);
  });

  group('AccountsProvider', () {
    test('initial state is correct', () {
      expect(provider.accounts, isEmpty);
      expect(provider.isLoading, isFalse);
      expect(provider.errorMessage, isNull);
    });

    test('fetchAccounts updates state correctly on success', () async {
      final accounts = [
        Account(id: 1, name: 'Savings', balance: 1000.0),
        Account(id: 2, name: 'Checking', balance: 500.0),
      ];

      when(mockApiService.getAccounts()).thenAnswer((_) async => accounts);

      await provider.fetchAccounts();

      expect(provider.accounts, equals(accounts));
      expect(provider.isLoading, isFalse);
      expect(provider.errorMessage, isNull);
    });

    test('fetchAccounts updates state correctly on error', () async {
      when(mockApiService.getAccounts()).thenThrow(Exception('Network error'));

      await provider.fetchAccounts();

      expect(provider.accounts, isEmpty);
      expect(provider.isLoading, isFalse);
      expect(provider.errorMessage, contains('Failed to fetch accounts'));
    });
  });
}