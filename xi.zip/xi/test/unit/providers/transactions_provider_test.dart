import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:xianyu_finance/models/transaction.dart';
import 'package:xianyu_finance/providers/transactions_provider.dart';
import 'package:xianyu_finance/services/api_service.dart';

class MockApiService extends Mock implements ApiService {}

void main() {
  late TransactionsProvider provider;
  late MockApiService mockApiService;
  final accountId = 1;

  setUp(() {
    mockApiService = MockApiService();
    provider = TransactionsProvider(mockApiService, accountId);
  });

  group('TransactionsProvider', () {
    test('initial state is correct', () {
      expect(provider.transactions, isEmpty);
      expect(provider.isLoading, isFalse);
      expect(provider.errorMessage, isNull);
    });

    test('fetchTransactions updates state correctly on success', () async {
      final transactions = [
        Transaction(id: '1', description: 'Groceries', amount: -50.0, date: DateTime.now()),
        Transaction(id: '2', description: 'Salary', amount: 1000.0, date: DateTime.now()),
      ];

      when(mockApiService.getTransactions(accountId)).thenAnswer((_) async => transactions);

      await provider.fetchTransactions();

      expect(provider.transactions, equals(transactions));
      expect(provider.isLoading, isFalse);
      expect(provider.errorMessage, isNull);
    });

    test('fetchTransactions updates state correctly on error', () async {
      when(mockApiService.getTransactions(accountId)).thenThrow(Exception('Network error'));

      await provider.fetchTransactions();

      expect(provider.transactions, isEmpty);
      expect(provider.isLoading, isFalse);
      expect(provider.errorMessage, contains('Failed to fetch transactions'));
    });
  });
}