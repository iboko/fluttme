import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:xianyu_finance/services/api_service.dart';
import 'package:xianyu_finance/models/account.dart';
import 'package:xianyu_finance/models/transaction.dart';

class MockDio extends Mock implements Dio {}

void main() {
  late ApiService apiService;
  late MockDio mockDio;

  setUp(() {
    mockDio = MockDio();
    apiService = ApiService(dio: mockDio);
  });

  group('ApiService', () {
    test('getAccounts returns list of accounts', () async {
      final mockResponse = Response(
        data: [
          {'id': 1, 'name': 'Savings', 'balance': 1000.0},
          {'id': 2, 'name': 'Checking', 'balance': 500.0},
        ],
        statusCode: 200,
        requestOptions: RequestOptions(path: ''),
      );

      when(mockDio.get('/accounts')).thenAnswer((_) async => mockResponse);

      final accounts = await apiService.getAccounts();

      expect(accounts.length, 2);
      expect(accounts[0].name, 'Savings');
      expect(accounts[1].name, 'Checking');
    });

    test('getTransactions returns list of transactions', () async {
      final accountId = 1;
      final mockResponse = Response(
        data: [
          {'id': '1', 'description': 'Groceries', 'amount': -50.0, 'date': '2023-07-30T10:00:00Z'},
          {'id': '2', 'description': 'Salary', 'amount': 1000.0, 'date': '2023-07-31T09:00:00Z'},
        ],
        statusCode: 200,
        requestOptions: RequestOptions(path: ''),
      );

      when(mockDio.get('/accounts/$accountId/transactions')).thenAnswer((_) async => mockResponse);

      final transactions = await apiService.getTransactions(accountId);

      expect(transactions.length, 2);
      expect(transactions[0].description, 'Groceries');
      expect(transactions[1].description, 'Salary');
    });

    test('createAccount creates and returns a new account', () async {
      final newAccount = Account(id: 0, name: 'New Account', balance: 0.0);
      final mockResponse = Response(
        data: {'id': 3, 'name': 'New Account', 'balance': 0.0},
        statusCode: 201,
        requestOptions: RequestOptions(path: ''),
      );

      when(mockDio.post('/accounts', data: newAccount.toJson())).thenAnswer((_) async => mockResponse);

      final createdAccount = await apiService.createAccount(newAccount);

      expect(createdAccount.id, 3);
      expect(createdAccount.name, 'New Account');
      expect(createdAccount.balance, 0.0);
    });

    
  });
}